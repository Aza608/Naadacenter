Naadam Center website

This is a static website. The homepage is index.html.

To publish on Vercel:
1. Sign in to Vercel.
2. Create a GitHub repository and upload index.html (or upload this folder's contents).
3. In Vercel choose Add New -> Project and import that repository.
4. Keep the default settings and click Deploy.
5. After deployment, Vercel will provide a public *.vercel.app URL.

Note: I cannot publish it into your Vercel account or reserve a specific project URL without access to your account. The requested naadamcenter.vercel.app name is only available if Vercel allows it and it is not already taken.
